var StarRating = extend(eg.Component,{
	ratingScore : 0,
	$eleRoot : '',
	$eleStar : '',
	$eleFirstStar : '',
	init : function($eleRoot, option){
		this.$eleRoot = $eleRoot;
		this.$eleStar = $eleRoot.find(".rating_rdo").not(".first_star");
		this.totalStarCount = this.$eleStar.length;
		this.$eleFirstStar = $eleRoot.find(".first_star");
	},
	action : function(event,param){
		observer.trigger("rating",event,param);
	},
	turnOnOffStar : function(score){
		this.$eleStar.prop("checked", false);
		this.$eleStar.slice(0,score).prop("checked", true);
		this.$eleRoot.find(".star_rank").text(score);
		this.ratingScore = score;
		this.$eleFirstStar.val(score);
	}
});

//별점 (.rating)

//review 입력
function controlReviewTxt(){
	$(".review_contents").on("click", function(){
		$(this).find(".review_write_info").hide();
		$("textarea").show().focus();
	});
	$("textarea").on("focusout", function(){
		if($(this).val() === ""){
			$(".review_contents .review_write_info").show();
		}
	});
}


//upload 리뷰 사진 미리보기
function previewReviewImg(){
	
	var $eleFile = $("#reviewImageFileOpenInput");

	var preview = {};
	$(".lst_thumb").on("click",".ico_del",function(){
		console.log(this.closest(".item").remove());
	});

	$eleFile.change(function(e){

		// files 반복문
		var file = e.target.files[0];

    	var reader = new FileReader();
    	var img;

    	reader.onload = function(e){
    		// console.log(e.target.result);
			preview.imgSrc = e.target.result;
			img = new Image();
            img.src = event.target.result;

            // width="130" alt="" class="item_thumb"
            img.width = 130;
            img.alt = "";
            $(img).addClass("item_thumb");

            console.log($(".lst_thumb .hide"));
            var html = $(".lst_thumb .hide").clone();

            console.log($(html));
            $(html).removeClass("hide");
			console.log(html);
			$(html).find("a").after(img);

			$(".lst_thumb").append(html);
            // $(".lst_thumb").append(html);
			// $(".lst_thumb").append(previewTemplate(event.target.result)); 
    	};
    	reader.readAsDataURL(file);
	});

	

}


//리뷰 등록

//document

$(function(){
	var starRating = new StarRating($(".rating"));

	$(".rating").on("click",".rating_rdo",function(e){
		starRating.turnOnOffStar(this.value);
	});

	controlReviewTxt();
	previewReviewImg();

	

	

});
